package com.hoangminh.dto;

import java.math.BigDecimal;

public interface chartByCategories {
	public String getname();
	public int getcount();
	public BigDecimal getsum();
	
	
}
