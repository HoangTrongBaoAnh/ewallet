package com.hoangminh.service;

import com.hoangminh.dto.Mail;

public interface mailservice {
	public void sendEmail(Mail mail);
}
