package com.hoangminh.service;

import com.hoangminh.dto.DocumentDTO;

public interface IDocumentService {

    DocumentDTO addDocumentById(DocumentDTO documentDTO);
}
